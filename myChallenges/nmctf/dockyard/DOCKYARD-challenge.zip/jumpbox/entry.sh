#!/bin/sh
# Set per-team SSH password from env var at boot
SSH_PASS="${SSH_PASSWORD:-numidian123}"
echo "ctf:${SSH_PASS}" | chpasswd
exec /usr/sbin/sshd -D -e
