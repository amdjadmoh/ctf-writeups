#!/bin/sh
echo "[DinD-Seeder] Waiting for internal Docker daemon..."

until docker info >/dev/null 2>&1; do
    sleep 1
done

echo "[DinD-Seeder] Docker ONLINE, checking Alpine..."
docker image inspect alpine:3.19 >/dev/null 2>&1 || docker pull alpine:3.19 >/dev/null 2>&1 || echo "[DinD-Seeder] Warn: Alpine pull issue"

echo "[DinD-Seeder] Creating secure-vault..."
docker rm -f secure-vault 2>/dev/null
docker run -d \
    --name secure-vault \
    --restart always \
    alpine:3.19 \
    tail -f /dev/null

sleep 0.5
docker exec secure-vault sh -c "mkdir -p /run/secrets && echo '$FLAG' > /run/secrets/audit_token"
echo "[DinD-Seeder] Vault seeded with flag"
