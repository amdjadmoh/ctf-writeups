#!/bin/bash
# Run vault seeder in background once Docker daemon is ready
(
  until docker info >/dev/null 2>&1; do sleep 1; done
  echo "[dind] Docker daemon ready, seeding vault..."
  /init-dind.sh
) &

# Run the original docker:dind entrypoint as main process
exec dockerd-entrypoint.sh "$@"
